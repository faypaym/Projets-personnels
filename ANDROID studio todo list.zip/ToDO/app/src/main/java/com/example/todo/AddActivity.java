/** @author : E.Charrier & B.Vandamme - 2020 */

package com.example.todo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;

public class AddActivity extends Activity {

    EditText nameTask;
    EditText dateTask;
    EditText descriptionTask;
    EditText lienTask;
    RadioButton maison;
    RadioButton jardin;

    boolean boolRetour = false;

    /**
     * Méthode de création et de l'instanciation de l'activité AddActivity
     * @param savedInstanceState (Bundle) : la sauvegarde précédente de l'application
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        nameTask = (EditText)findViewById(R.id.name);
        nameTask.setSelectAllOnFocus(true);
        dateTask   = (EditText) findViewById(R.id.date);
        dateTask.setSelectAllOnFocus(true);
        descriptionTask   = (EditText) findViewById(R.id.desc);
        descriptionTask.setSelectAllOnFocus(true);
        lienTask = (EditText) findViewById(R.id.lien);
        lienTask.setSelectAllOnFocus(true);

        maison = (RadioButton) findViewById(R.id.radio_maison);
        jardin = (RadioButton) findViewById(R.id.radio_jardin);

        Button retour = (Button) findViewById(R.id.button);
        retour.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolRetour = true;
                finish();
            }
        }));
    }

    /**
     * Méthode de fin de l'activité AddActivity
     */
    @Override
    public void finish(){
        Intent returnIntent = new Intent();
        if(boolRetour){
            returnIntent.putExtra("task_name",nameTask.getText().toString());
            returnIntent.putExtra("task_date",dateTask.getText().toString());
            if(maison.isChecked()){
                returnIntent.putExtra("task_type","Maison");
            }else if (jardin.isChecked()){
                returnIntent.putExtra("task_type","Jardin");
            }else {
                returnIntent.putExtra("task_type","Autre");
            }
            returnIntent.putExtra("task_desc",descriptionTask.getText().toString());
            returnIntent.putExtra("task_lien",lienTask.getText().toString());
        }
        setResult(RESULT_OK, returnIntent);
        super.finish();
    }
}