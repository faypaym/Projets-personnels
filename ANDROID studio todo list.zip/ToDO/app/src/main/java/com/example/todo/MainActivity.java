/** @author : E.Charrier & B.Vandamme - 2020 */

package com.example.todo;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private ArrayList<Task> tasksListArray;
    private ListView list;
    Adapter adapter;

    RadioGroup radio;

    int updatePosition;

    /**
     * Méthode de création et de l'instanciation de l'activité MainActivity
     * @param savedInstanceState (Bundle) : la sauvegarde précédente de l'application
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        list = (ListView) findViewById(R.id.taskList);
        tasksListArray = new ArrayList<Task>();

        RadioButton tous = (RadioButton) findViewById(R.id.radioButton4);
        tous.setChecked(true);

        Task t1 = new Task("Ranger la maison", new Date("2019/11/12 12:30:00"), "Maison", "Il faut ranger la maison avant l'arrivée des invités", null);
        Task t2 = new Task("Tondre la pelouse", new Date("2019/11/12 12:30:00"), "Jardin", "Il faut tondre le gazon et ensuite emmener les herbes à la déchetterie", null);
        Task t3 = new Task("Chercher du pain", new Date("2019/11/12 12:30:00"), "Autre", null, null);

        tasksListArray.add(t1);
        tasksListArray.add(t2);
        tasksListArray.add(t3);

        adapter = new Adapter(this, tasksListArray);
        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Task selectedItem = (Task) adapter.getItem(position);
                updatePosition = position;
                Intent myIntent = new Intent(getApplicationContext(), UpdateActivity.class);
                myIntent.putExtra("task", selectedItem);
                startActivityForResult(myIntent, 2);

            }
        });

        FloatingActionButton add = (FloatingActionButton) findViewById(R.id.actionB);
        add.setClickable(true);
        add.setOnClickListener(this);

        radio = (RadioGroup) findViewById(R.id.radioGroup);
        radio.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                updateView();
            }
        });
    }

    /**
     * Méthode de mise à jour l'affichage de la ListView
     */
    public void updateView(){
        RadioButton maison = (RadioButton) findViewById(R.id.maison);
        RadioButton jardin = (RadioButton) findViewById(R.id.jardin);
        RadioButton autre = (RadioButton) findViewById(R.id.autre);
        ArrayList<Task> tasks = new ArrayList<>();
        if(maison.isChecked()){
            for(int i = 0; i < tasksListArray.size(); i++){
                if(tasksListArray.get(i).getTaskType().equals("Maison"))
                tasks.add(tasksListArray.get(i));
            }
        }else if(jardin.isChecked()) {
            for (int i = 0; i < tasksListArray.size(); i++) {
                if (tasksListArray.get(i).getTaskType().equals("Jardin")) {
                    tasks.add(tasksListArray.get(i));
                }
            }
        }else if(autre.isChecked()){
            for(int i = 0; i < tasksListArray.size(); i++){
                    if(tasksListArray.get(i).getTaskType().equals("Autre")) {
                    tasks.add(tasksListArray.get(i));
                }
            }
        }else {
            tasks = tasksListArray;
        }
        adapter = new Adapter(this,tasks);
        list.setAdapter(adapter);
    }

    /**
     * Méthode d'appel de l'activité AddActivity pour ajouter une nouvelle activité à la liste
     * @param v (View) :
     */
    @Override
    public void onClick(View v) {
        Intent myIntent = new Intent(this, AddActivity.class);
        startActivityForResult(myIntent, 1);
    }

    /**
     * Méthode de retour lors de l'exécution d'un appel à une autre activité
     * @param requestCode (int) : Code de la requête appellante
     * @param resultCode (int) : Code de la requête de retour
     * @param data (Intent) : l'objet Intent qui contient un packetage de données. Peut être null
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1){
            if(resultCode == RESULT_OK){
                if(data.hasExtra("task_name") && data.hasExtra("task_date") && data.hasExtra("task_type") && data.hasExtra("task_desc")){
                    String date;
                    if(data.getExtras().getString("task_date").equals("date")){
                        date = new SimpleDateFormat("dd/MM/YY").format(new Date());
                    }else {
                        date = data.getExtras().getString("task_date");
                    }
                    tasksListArray.add(new Task(data.getExtras().getString("task_name"),date,data.getExtras().getString("task_type"),data.getExtras().getString("task_desc"),data.getExtras().getString("task_lien")));
                }
            }
        }else if(requestCode == 2){
            if(resultCode == RESULT_OK){
                if (data.getExtras().getString("order").equals("delete")) {
                    System.out.println("REMOVE : " + data.getExtras().getInt("id"));
                    tasksListArray.remove(data.getExtras().getInt("id"));
                }else if (data.getExtras().getString("order").equals("update")){
                    tasksListArray.set(updatePosition,(Task) data.getParcelableExtra("task"));
                }
                list.setAdapter(adapter);
            }
        }
        updateView();
    }
}
