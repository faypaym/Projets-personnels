/** @author : E.Charrier & B.Vandamme - 2020 */

package com.example.todo;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.Nullable;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Task implements Parcelable {

    private String taskName;
    private String taskDesc;
    private String taskType;
    private String taskDate;
    private  String taskLien;

    /**
     * Constructeur de la classe Task
     * @param name (String) : nom de la tâche
     * @param date (Date) : date de la tâche
     * @param type (String) : type de la tâche
     * @param desc (String) : description de la tâche. Peut être égale à null
     * @param lien (String) : lien de la tâche. Peut être égale à null
     */
    public Task(String name, Date date, String type, @Nullable String desc, @Nullable String lien){
        taskName = name;
        taskDesc = desc;
        taskType = type;
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yy");
        try {
            taskDate = dateFormat.format(date);
        }catch (Exception e){
            System.err.println("Error");
        }
        taskLien = lien;
    }

    /**
     * Constructeur de la classe Task
     * @param name (String) : nom de la tâche
     * @param date (String) : date de la tâche
     * @param type (String) : type de la tâche
     * @param desc (String) : description de la tâche. Peut être égale à null
     * @param lien (String) : lien de la tâche. Peut être égale à null
     */
    public Task(String name, String date, String type, @Nullable String desc, @Nullable String lien){
        taskName = name;
        taskDesc = desc;
        taskType = type;
        taskDate = date;
        taskLien = lien;
    }

    public String getTaskName(){
        return  taskName;
    }

    public String getTaskType(){
        return  taskType;
    }

    public String getTaskDate(){
        return taskDate;
    }

    public String getTaskDesc() { return taskDesc; }

    public String getTaskLien() { return taskLien; }

    public void setTaskDate(String taskDate) { this.taskDate = taskDate; }

    public void setTaskName(String taskName) { this.taskName = taskName; }

    public void setTaskType(String taskType) { this.taskType = taskType; }

    public void setTaskDesc(String taskDesc) { this.taskDesc = taskDesc; }

    public void setTaskLien(String taskLien) { this.taskLien = taskLien; }

    /** Méthodes de sérialisation de l"objet Task*/

    /**
     * @param in (Parcel) :
     */
    protected Task(Parcel in) {
        taskName = in.readString();
        taskDesc = in.readString();
        taskType = in.readString();
        taskDate = in.readString();
        taskLien = in.readString();
    }

    /**
     */
    public static final Creator<Task> CREATOR = new Creator<Task>() {
        /**
         * @param in (Parcel) :
         * @return Task
         */
        @Override
        public Task createFromParcel(Parcel in) {
            return new Task(in);
        }

        /**
         * @param size (int) :
         * @return Task[]
         */
        @Override
        public Task[] newArray(int size) {
            return new Task[size];
        }
    };

    /**
     * @return int
     */
    @Override
    public int describeContents() {
        return 0;
    }

    /**
     * @param dest (Parcel) :
     * @param flags (int) :
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(taskName);
        dest.writeString(taskDesc);
        dest.writeString(taskType);
        dest.writeString(taskDate);
        dest.writeString(taskLien);
    }
}
