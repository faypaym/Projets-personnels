/** @author : E.Charrier & B.Vandamme - 2020 */

package com.example.todo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class UpdateActivity extends AppCompatActivity {

    EditText nameTask;
    EditText dateTask;
    EditText descriptionTask;
    EditText lienTask;
    RadioButton maison;
    RadioButton jardin;
    RadioButton autre;

    boolean boolUpdate = false;
    boolean boolDelete = false;

    int position;
    Task task;

    /**
     * Méthode de création et de l'instanciation de l'activité UpdateActivity
     * @param savedInstanceState (Bundle) : la sauvegarde précédente de l'application
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        Intent intent = getIntent();
        task = intent.getParcelableExtra("task");
        position = intent.getIntExtra("id",position);

        nameTask = (EditText)findViewById(R.id.name);
        nameTask.setText(task.getTaskName());
        nameTask.setSelectAllOnFocus(true);

        dateTask = (EditText) findViewById(R.id.date);
        dateTask.setText(task.getTaskDate());
        dateTask.setSelectAllOnFocus(true);

        descriptionTask   = (EditText) findViewById(R.id.desc);
        descriptionTask.setText(task.getTaskDesc());
        descriptionTask.setSelectAllOnFocus(true);

        lienTask = (EditText) findViewById(R.id.lien);
        lienTask.setText(task.getTaskLien());
        lienTask.setSelectAllOnFocus(true);

        maison = (RadioButton) findViewById(R.id.radio_maison);
        jardin = (RadioButton) findViewById(R.id.radio_jardin);
        autre = (RadioButton) findViewById(R.id.radio_autre);

        if(task.getTaskType().equals("Maison")){
            maison.setChecked(true);
        }else if(task.getTaskType().equals("Jardin")){
            jardin.setChecked(true);
        }else {
            autre.setChecked(true);
        }
        if(task.getTaskDesc() == null){
            descriptionTask.setText("Description (facultatif)");
        }
        if(task.getTaskLien() == null) {
            lienTask.setText("Lien (facultatif)");
        }

        Button update = (Button) findViewById(R.id.button);
        update.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolUpdate = true;
                finish();
            }
        }));

        Button delete = (Button) findViewById(R.id.button2);
        delete.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolDelete = true;
                finish();
            }
        }));

        Button go = (Button) findViewById(R.id.button3);
        go.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(getApplicationContext(), WebApp.class);
                myIntent.putExtra("url", lienTask.getText().toString());
                startActivityForResult(myIntent, 1);
            }
        }));
    }

    /**
     * Méthode de fin de l'activité UpdateActivity
     */
    @Override
    public void finish(){
        Intent returnIntent = new Intent();
        if(boolUpdate){
            returnIntent.putExtra("order","update");
            task.setTaskName(nameTask.getText().toString());
            task.setTaskDate(dateTask.getText().toString());
            if(maison.isChecked()){
                task.setTaskType("Maison");
            }else if (jardin.isChecked()){
                task.setTaskType("Jardin");
            }else {
                task.setTaskType("Autre");
            }
            task.setTaskDesc(descriptionTask.getText().toString());
            task.setTaskLien(lienTask.getText().toString());
        }else if (boolDelete){
            returnIntent.putExtra("order","delete");
        }else{
            returnIntent.putExtra("order","return");
        }
        returnIntent.putExtra("task",task);
        returnIntent.putExtra("id",position);
        setResult(RESULT_OK, returnIntent);
        super.finish();
    }

    /**
     * Méthode de retour lors de l'exécution d'un appel à une autre activité
     * @param requestCode (int) : Code de la requête appellante
     * @param resultCode (int) : Code de la requête de retour
     * @param data (Intent) : l'objet Intent qui contient un packetage de données. Peut être null
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }

}
