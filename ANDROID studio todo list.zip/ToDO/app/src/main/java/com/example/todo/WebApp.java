/** @author : E.Charrier & B.Vandamme - 2020 */

package com.example.todo;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class WebApp extends AppCompatActivity{

    WebView webview;
    String url;

    /**
     * Méthode de création et de l'instanciation de l'activité WebApp
     * @param savedInstanceState (Bundle) : la sauvegarde précédente de l'application
     */
    @SuppressLint("JavascriptInterface")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_webview);

        Intent intent = getIntent();
        url = intent.getStringExtra("url");
        if(!url.contains("https://")){
            url = "https://google.com";
        }

        webview = (WebView) findViewById(R.id.WebView);

        WebSettings params = webview.getSettings();
        params.setJavaScriptEnabled(true);
        params.setBuiltInZoomControls(true);
        webview.setWebViewClient(new MyWebViewClient());
        webview.loadUrl(url);

    }

    /**
     * Méthode de fin de l'activité WebApp
     */
    @Override
    public void finish(){
        super.finish();
    }

    private class MyWebViewClient extends WebViewClient {
        /**
         * @param view (WebView) : la WebView qui affichera l'url passée également en paramètre
         * @param url (String) : l'url à afficher dans la WebView
         * @return boolean
         */
        @Override
        public boolean shouldOverrideUrlLoading(WebView view,String url){
            view.loadUrl(url);
            return  true;
        }
    }

}
