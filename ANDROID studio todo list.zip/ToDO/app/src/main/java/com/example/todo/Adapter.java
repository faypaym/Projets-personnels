/** @author : E.Charrier & B.Vandamme - 2020 */

package com.example.todo;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;

public class Adapter extends BaseAdapter {
    private List<Task> listTask;
    private Context context;
    private LayoutInflater inflater;

    /**
     * Constructeur de la classe Adapter
     * @param context (Context) :
     * @param list (List<Task>) : l'objet de type List contenant des objets Task
     */
    public Adapter(Context context, List<Task> list){
        listTask = list;
        context = context;
        inflater = LayoutInflater.from(context);
    }

    /**
     * Retourne la taille de la liste
     * @return int
     */
    @Override
    public int getCount(){
        return  listTask.size();
    }

    /**
     * Retourne un objet de type Objet au rang position dans la liste
     * @param position (int) : la position de l'objet à récupérer
     * @return Object
     */
    @Override
    public Object getItem(int position){
        return listTask.get(position);
    }

    /**
     * Retourne l'identifiant au format long de l'objet au rang position dans la liste
     * @param position (int) : la position de l'objet
     * @return long
     */
    @Override
    public long getItemId(int position){
        return  position;
    }

    /**
     * Retourne un objet de type View pour permettre l'affichage de l'Adapter
     * @param position (int) : la position de l'objet à récupérer
     * @param convertView (View) : la vue à convertir
     * @param parent (ViewGroup) : le groupe auquel appartient la View
     * @return View
     */
    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        View view;

        if(convertView == null){
            view = (View) inflater.inflate(R.layout.tache_list_item,parent,false);
        }
        else {
            view = (View) convertView;
        }


        TextView nameTask = (TextView) view.findViewById(R.id.tacheName);
        TextView dateTask = (TextView) view.findViewById(R.id.dateTache);
        TextView typeTask = (TextView) view.findViewById(R.id.TypeTache);

        nameTask.setText(listTask.get(position).getTaskName());
        typeTask.setText(listTask.get(position).getTaskType());

        String date = listTask.get(position).getTaskDate();
        dateTask.setText("A faire avant le : "+date);

        return view;

    }


}
