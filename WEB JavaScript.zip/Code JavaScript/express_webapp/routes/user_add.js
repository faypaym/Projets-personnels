var express = require('express');
var router = express.Router();
var user_dao = require('sport-track-db/sport-track-db').user_dao;

router.post('/', function(req, res, next) {
    user_dao.doesExist(req.body.mail, function(err, exists){
        if (exists) {
            res.render('webform', {inscrErr: true});
        }else {
            user_dao.insert(req.body.mail, req.body.prenom, req.body.nom, req.body.sexe, req.body.naissance, req.body.mdp, req.body.poids, function() {
                console.log("Insertion effectuée avec succès");
            });
            res.render('connexion', {inscrSucc: true});
        }
    });

});
module.exports = router;
