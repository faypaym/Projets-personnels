var express = require('express');
var router = express.Router();
var user_dao = require('sport-track-db/sport-track-db').user_dao;
var activity_dao = require('sport-track-db/sport-track-db').activity_dao;
var activity_entry_dao = require('sport-track-db/sport-track-db').activity_entry_dao;
var jsonFile = require('../public/javascripts/JsonFile');

router.post('/', async function(req, res, next) {
    let modBut = false;
    let impBut = false;
    let actBut = false;
    let modEff = false;
    let upEff = false;

    if (req.body.btnMod) {
        modBut = true;
        impBut = false;
        actBut = false;
        modEff = false;
        upEff = false;
    }

    if (req.body.btnAcc) {
        modBut = false;
        impBut = false;
        actBut = false;
        modEff = false;
        upEff = false;
    }
    if (req.body.btnImp) {
        modBut = false;
        impBut = true;
        actBut = false;
        modEff = false;
        upEff = false;
    }
    if (req.body.btnDec) {
        req.session.destroy();
        res.render('connexion');
    }
    if (req.body.btnAct) {
        modBut = false;
        impBut = false;
        actBut = true;
        modEff = false;
        upEff = false;
        await activity_dao.findByMail(req.session.userMail, async function(rows) {
            req.session.activities = rows;
        });
    }

    if (req.body.btnSupAct) {
        await activity_dao.delete(req.session.userMail,function () {
            console.log("Activités supprimées");
        });
    }

    if (req.body.btnEnvMod) {
        await user_dao.update(req.session.userMail, req.body.prenom, req.body.nom, req.body.sexe, req.body.naissance, req.body.mdp, req.body.poids, function (err) {
            console.log("Modification effectuée")
        });
        await user_dao.findByKey(req.session.userMail, async function(rows){
            req.session.user = rows[0];
        });
        modEff = true;
    }

    if (req.body.btnEnvFile) {
        var file = req.files.jsonFile;

        var myFile = JSON.parse(file.data.toString());
        jsonFile.init(myFile);

        var noActivity;
        await activity_dao.findAll(function (rows) {
            noActivity = rows.length + 1;
        });

        var idAct = noActivity;
        var date = jsonFile.getDate();
        var descr = jsonFile.getDescription();
        var debut = jsonFile.getDebut();
        var duree = jsonFile.getDuree();
        var dP = jsonFile.getDistanceparcourue();
        var fqMin = jsonFile.getFreqMin();
        var fqMoy = jsonFile.getFreqMoy();
        var fqMax = jsonFile.getFreqMax();


        await activity_dao.insert(idAct, "", date, descr, debut, duree, dP, fqMin, fqMoy, fqMax, req.session.user.mail, function(err) {
                if (err) {
                    console.log("Insertion dans activity_dao: erreur");
                }else{
                    console.log("Insertion dans activity_dao: succès");
                }
            });

        var noActivityEntry;
        await activity_entry_dao.findAll(function (rows) {
            noActivityEntry = rows.length + 1;
        });

        for(var i=noActivityEntry; i<myFile.data.length; i++) {
            activity_entry_dao.insert(i, myFile.data[i].latitude, myFile.data[i].longitude, myFile.data[i].altitude,
                myFile.data[i].time, myFile.data[i].cardio_frequency, idAct, function(err) {
                    if (err) {
                        console.log("Insertion dans activity_entry_dao: erreur");
                    }else{
                        console.log("Insertion dans activity_entry_dao: succès");
                    }
                });
        }
        upEff = true;

    }

    res.render('connexion_succeed', {modBut: modBut, impBut: impBut, upEff: upEff, modEff: modEff, actBut: actBut, user: req.session.user, activities: req.session.activities});
});
module.exports = router;
