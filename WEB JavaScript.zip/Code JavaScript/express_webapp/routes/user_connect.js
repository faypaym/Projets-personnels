var express = require('express');
var router = express.Router();
var user_dao = require('sport-track-db/sport-track-db').user_dao;

router.post('/', async function(req, res, next) {
    user_dao.checkPassword(req.body.mail, req.body.mdp, async function(err, succeed){
        if (succeed) {
            req.session.userMail = req.body.mail;
            await user_dao.findByKey(req.body.mail, async function(rows){
                req.session.user = rows[0];
            });
            res.render('connexion_succeed', {modBut: false, impBut: false, actBut: false});
        }else {
            res.render('connexion', {erreurCon: true});
        }
    });
});
module.exports = router;
