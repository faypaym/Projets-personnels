var express = require('express');
var router = express.Router();
var user_dao = require('sport-track-db/sport-track-db').user_dao;

/* GET users listing. */
router.get('/', function(req, res, next) {
    res.render('webform');
});
module.exports = router;
