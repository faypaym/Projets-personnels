
var Calculs = function () {

  this.calculDistance2PointsGPS = function (la1, la2, lo1, lo2) {
    R = 6378.137;
    var lat1 = (Math.PI * la1)/ 180;
    var lat2 = (Math.PI * la2)/ 180;
    var long1 = (Math.PI * lo1)/180;
    var long2 = (Math.PI * lo2)/180;
    distance = R * Math.acos((Math.sin(lat2) * Math.sin(lat1)) + (Math.cos(lat2) * Math.cos(lat1) * Math.cos(long2 - long1)));
    return distance;
  }

  this.calculDistanceTrajet = function (array) {
    var distance = 0;
    for (var i=0; i < array.data.length-1; i++) {
      distance += this.calculDistance2PointsGPS(array.data[i].latitude, array.data[i+1].latitude, array.data[i].longitude, array.data[i+1].longitude);
    }
    return distance;
  }

  this.toHHMMSS = function (seconds) {
    var sec_num = parseInt(seconds, 10); // don't forget the second param
    var hours   = Math.floor(sec_num / 3600);
    var minutes = Math.floor((sec_num - (hours * 3600)) / 60);
    var seconds = sec_num - (hours * 3600) - (minutes * 60);

    if (hours   < 10) {hours   = "0"+hours;}
    if (minutes < 10) {minutes = "0"+minutes;}
    if (seconds < 10) {seconds = "0"+seconds;}
    return hours+':'+minutes+':'+seconds;
  }
}

var calc = new Calculs();
module.exports = calc;