var express = require('express');
var fonction = require('./fonction');
var activity_dao = require('sport-track-db/sport-track-db').activity_dao;

var JsonFile = function() {

    this.init = function(json) {
        this.json = json;
    }

    this.getIdAct = async function() {
        var noActivity = 0;
        await activity_dao.findAll( function (rows) {
            noActivity = rows.length + 1;
        });
        return noActivity;
    }

    this.getDate = function() {
        return this.json.activity.date;
    }

    this.getDescription = function() {
        return this.json.activity.description;
    }

    this.getDebut = function() {
        var ret;
        if (this.json.data.length > 0) {
            ret = this.json.data[0].time;
        }
        return ret;
    }

    this.getDuree = function() {
        var tmpTimeD = this.json.data[0].time;
        var tmpTimeF = this.json.data[this.json.data.length-1].time;

        var timeD = tmpTimeD.split(":");
        var timeF = tmpTimeF.split(":");

        var ret = (timeF[0]*3600 + timeF[1]*60 + timeF[2]) - (timeD[0]*3600 + timeD[1]*60 + timeD[2]);

        return fonction.toHHMMSS(ret);
    }

    this.getDistanceparcourue = function() {
        var ret = fonction.calculDistanceTrajet(this.json);
        ret = ret.toFixed(3);

        return ret;
    }

    this.getFreqMin = function() {
        var ret = 0;
        if (this.json.data.length > 0) {
            ret = this.json.data[0].cardio_frequency;
            for (var i = 1; i < this.json.data.length; i++) {
                if (this.json.data[i].cardio_frequency < ret) {
                    ret = this.json.data[i].cardio_frequency
                }
            }
        }
        return ret;
    }

    this.getFreqMax = function() {
        var ret = 0;
        if (this.json.data.length > 0) {
            ret = this.json.data[0].cardio_frequency;
            for (var i = 1; i < this.json.data.length; i++) {
                if (this.json.data[i].cardio_frequency > ret) {
                    ret = this.json.data[i].cardio_frequency
                }
            }
        }
        return ret;
    }

    this.getFreqMoy = function() {
        var ret = 0;
        if (this.json.data.length > 0) {
            ret = this.json.data[0].cardio_frequency;
            for (var i = 1; i < this.json.data.length; i++) {
                ret += this.json.data[i].cardio_frequency
            }
            ret = ret / this.json.data.length;
        }
        return ret.toFixed();
    }

}

var jsonFile = new JsonFile();
module.exports = jsonFile;