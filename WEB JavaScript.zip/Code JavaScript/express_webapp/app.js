var createError = require('http-errors');
const express = require('express');
const session = require('express-session');
const upload = require('express-fileupload');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');
var users = require('./routes/users');
var registration = require('./routes/registration');
var connect = require('./routes/connect');
var user_add = require('./routes/user_add');
var user_connect = require('./routes/user_connect');
var user_connected = require('./routes/user_connected');


var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use(upload({secret: 'expressFileUpload'}));
app.use(session({secret: 'expressSession'}));
app.use('/', connect);
app.use('/users', usersRouter);
app.use('/users',users);
app.use('/webform',registration);
app.use('/user_add',user_add);
app.use('/user_connect',user_connect);
app.use('/user_connected',user_connected);

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
