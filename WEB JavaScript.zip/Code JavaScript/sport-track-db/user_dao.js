var db = require('./sqlite_connection');

var UserDAO = function(){
	
	this.findAll = function (callback) {
		return new Promise((resolve, reject) => {
			db.all("SELECT * FROM Utilisateur", function(err, rows) {
				if (err) {
					reject(err);
				}else{
					resolve(callback(err,rows));
				}
			});
		});
	}
		
    this.insert = function (mail, prenomUt, nomUt, sexe, dateNais, mdp, poids, callback) {
		return new Promise((resolve, reject) => {
			db.run("INSERT INTO Utilisateur(mail, prenomUt, nomUt, sexe, dateNais, mdp, poids) VALUES (?, ?, ?, ?, ?, ?, ?)", [mail, prenomUt, nomUt, sexe, dateNais, mdp, poids], function(err) {
				if (err) {
					reject(err);
				}else{
					resolve(callback(err));
				}
			});
		});
	}
	
	this.update = function (mail, prenomUt, nomUt, sexe, dateNais, mdp, poids, callback) {
		db.run("UPDATE Utilisateur SET prenomUt= ?, nomUt= ?, sexe= ?, dateNais= ?, mdp= ?, poids= ? WHERE mail= ?", [prenomUt, nomUt, sexe, dateNais, mdp, poids, mail], function(err) {
			if (err) {
				console.log(err);
			}else{
				callback(err);
			}
		});
	}
	
	this.delete = function (mail, callback) {
		return new Promise((resolve, reject) => {
			db.run("DELETE FROM Utilisateur WHERE mail= ?", mail, function(err) {
				if (err) {
					reject(err);
				}else{
					resolve(callback(err));
				}
			});
		});
	}
	
	this.deleteAll = function (callback) {
		return new Promise((resolve, reject) => {
			db.run("DELETE FROM Utilisateur", function(err) {
				if (err) {
					reject(err);
				}else{
					resolve(callback(err));
				}
			});
		});
	}

	this.findByKey = async function (mail, callback) {
		return new Promise((resolve, reject) => {
			db.all("SELECT * FROM Utilisateur WHERE mail= ?", mail, function(err, rows) {
				if (err) {
					reject(err);
				}else{
					resolve(callback(rows));
				}
			});
		});
	}


	this.doesExist = function (mail, callback) {
			db.all("SELECT * FROM Utilisateur WHERE mail= ?", mail, function(err, exists) {
				callback(err, exists ? exists.length === 1 : true);
			});
	}

	this.checkPassword = function (mail, mdp, callback) {
		db.all("SELECT * FROM Utilisateur WHERE mail= ? AND mdp= ?", mail, mdp, function(err, exists) {
			callback(err, exists ? exists.length === 1 : true);
		});
	}


};
var dao = new UserDAO();
module.exports = dao;

