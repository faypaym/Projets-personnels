var db = require('./sqlite_connection');

var ActivityEntryDAO = function(){


	this.findAll = function(callBack){
		return new Promise((resolve,reject) => {
			db.all("SELECT*FROM POINT",function(err,rows){
				if(err){
					reject(err);
				}else{
					resolve(callBack(rows));
				}
			});
		});
	}


	this.insert = function(idPt,latitude,longitude,altitude,temps,cardio,lActivite,callBack){
		return new Promise((resolve,reject) => {
			db.run("INSERT INTO POINT(idPt,latitude,longitude,altitude,temps,cardio,lActivite) VALUES (?,?,?,?,?,?,?)", [idPt,latitude,longitude,altitude,temps,cardio,lActivite,callBack], function(err) {
				if(err){
					reject(err);
				}else{
					resolve(callBack(err));
				}
			});
		});
	}

	this.update = function (idPt,latitude,longitude,altitude,temps,cardio,lActivite,callBack) {
		return new Promise((resolve, reject) => {
			db.run("UPDATE POINT SET idPt= ?, latitude= ?, longitude= ?, altitude= ?, temps= ?, cardio= ?, lActivite= ? WHERE idPt= ?", [idPt,latitude,longitude,altitude,temps,cardio,lActivite,callBack], function(err) {
				if (err) {
					reject(err);
				}else{
					resolve(callback(err));
				}
			});
		});
	}


	this.delete = function (idPt, callback) {
			return new Promise((resolve, reject) => {
				db.run("DELETE FROM POINT WHERE idPt= ?", idPt, function(err) {
					if (err) {
						reject(err);
					}else{
						resolve(callback(err));
					}
				});
			});
		}

	this.deleteAll = function (callback) {
		return new Promise((resolve, reject) => {
			db.run("DELETE FROM POINT", function(err) {
				if (err) {
					reject(err);
				}else{
					resolve(callback(err));
				}
			});
		});
	}



	this.findByKey = function (idPt, callback) {
		return new Promise((resolve, reject) => {
			db.each("SELECT * FROM POINT WHERE idPt= ?", idPt, function(err, rows) {
				if (err) {
					reject(err);
				}else{
					resolve(callback(err,rows));
				}
			});
		});
	}
}
var dao = new ActivityEntryDAO();
module.exports = dao;
