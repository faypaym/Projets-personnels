var user_dao = require('./sport-track-db').user_dao;
var activity_entry_dao = require('./sport-track-db').activity_entry_dao;
var db = require('./sport-track-db').db_connection;

user_dao.findAll(function(err,rows){
	if (err) {
		console.log(err);
	}else{
		for (r of rows) {
			console.log("mail:"+r.mail+"\t firstname:"+r.prenomUt);
		}
	}
});

user_dao.insert("1","120","1","1","12","1","1", function() {
	console.log("Insertion effectuée avec succès");
});



user_dao.findAll(function(err,rows){
	if (err) {
		console.log(err);
	}else{
		for (r of rows) {
			console.log("mail:"+r.mail+"\t firstname:"+r.prenomUt);
		}
	}
});



