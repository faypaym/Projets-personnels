let path = require('path');
let sqlite3 = require('sqlite3').verbose();

let db = new sqlite3.Database(path.resolve('../sport-track-db/sport_track.db'), sqlite3.OPEN_READWRITE,(err)=>{
	if(err){
		console.log("DataBase connection failed !"+err.message);
	}else{
		console.log("DataBase connection succeeded !");
	}
});
module.exports = db;
