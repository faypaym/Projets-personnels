var db = require('./sqlite_connection');

var ActivityDAO = function(){

	this.findAll = function(callBack){
		return new Promise((resolve,reject) => {
			db.all("SELECT * FROM Activite",function(err,rows){
				if(err){
					reject(err);
				}else{
					resolve(callBack(rows));
				}
			});
		});
	}

	this.findByMail = function(mail, callBack){
		return new Promise((resolve,reject) => {
			db.all("SELECT * FROM Activite WHERE lUtilisateur= ?", mail,function(err,rows){
				if(err){
					reject(err);
				}else{
					resolve(callBack(rows));
				}
			});
		});
	}


	this.insert = function(idAct,nomAct,dateAct,descriptionAct,debut,duree,distanceParcourue,freqCardMin,freqCardMoy,freqCardmax,lUtilisateur,callBack){
		return new Promise((resolve,reject) => {
			db.run("INSERT INTO Activite(idAct,nomAct,dateAct,descriptionAct,debut,duree,distanceParcourue,freqCardMin,freqCardMoy,freqCardmax,lUtilisateur) VALUES (?,?,?,?,?,?,?,?,?,?,?)", [idAct, nomAct, dateAct, descriptionAct, debut, duree, distanceParcourue, freqCardMin,freqCardMoy,freqCardmax,lUtilisateur], function(err) {
				if(err){
					reject(err);
				}else{
					resolve(callBack(err));
				}
			});
		});
	}


	this.update = function (idAct,nomAct,dateAct,descriptionAct,debut,duree,distanceParcourue,freqCardMin,freqCardMoy,freqCardmax,lUtilisateur,callBack) {
		return new Promise((resolve, reject) => {
			db.run("UPDATE ACTIVITE SET idAct= ?, nomAct= ?, dateAct= ?, descriptionAct= ?, debut= ?, duree= ?, distanceParcourue= ? , freqCardMin=?, freqCardMoy=?, freqCardmax=?,lUtilisateur=? WHERE idAct= ?", [idAct, nomAct, dateAct, descriptionAct, debut, duree, distanceParcourue, freqCardMin,freqCardMoy,freqCardmax,lUtilisateur], function(err) {
				if (err) {
					reject(err);
				}else{
					resolve(callback(err));
				}
			});
		});
	}


	this.delete = function (mail, callback) {
			return new Promise((resolve, reject) => {
				db.run("DELETE FROM Activite WHERE lUtilisateur= ?", mail, function(err) {
					if (err) {
						reject(err);
					}else{
						resolve(callback(err));
					}
				});
			});
		}
		
	this.deleteAll = function (callback) {
		return new Promise((resolve, reject) => {
			db.run("DELETE FROM Activite", function(err) {
				if (err) {
					reject(err);
				}else{
					resolve(callback(err));
				}
			});
		});
	}



	this.findByKey = function (idAct, callback) {
		return new Promise((resolve, reject) => {
			db.each("SELECT * FROM Activite WHERE idAct= ?", idAct, function(err, rows) {
				if (err) {
					reject(err);
				}else{
					resolve(callback(err,rows));
				}
			});
		});
	}
}
var dao = new ActivityDAO();
module.exports = dao;
