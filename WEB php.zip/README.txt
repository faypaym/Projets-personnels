

=== État d'avancement de l'application:

L'apllication est fonctionnelle, il est bien possible de s'inscrire sur l'application, de se connecter.
Une fois connecté, il est possible de modifier/consulter ses informations personnelles, d'ajouter une activité
grâce à l'import d'un fichier en format .json. Il est bien possible d'ajouter plusieurs activités, de les consulter
et de les supprimer si voulu.

=== Architecture de l'application :

--La première page du site est la page de connection (vue: connexion.php) controllée par le controlleur : ConnectionController.php 
qui gère la connexion au site. On trouve en dessous du bouton "connexion" un lien qui permet de s'inscrire; si le lien
est cliqué on arrive sur la page d'inscription.
--La page inscription (vue: webform.php) est controllée par le controlleur : AddUserController.php.Cette page 
permet de s'inscrire, affiche un petit message d'erreur si l'email est déjà renseigné et possède un lien en bas 
de page pour accéder à la page connexion.
--Une fois connecté on arrive sur la vue : ConnectUserValidationView.php controllée par le controleur ConnectedControlleur.php.
La vue affiche par défaut une image de fond avec un bandeau en haut de page comportant plusieurs boutons :
	* Le bouton "Déconnexion" qui nous déconnecte et nous renvoie à la page de connexion.
	* Le bouton "Accueil" qui permet de retourner à l'état initial de la page.
	* Le bouton "Modifier le profil" qui permet de consulter/modifier ses informations personnelles.
	* Le bouton "Liste d'activités" qui permet de consulter/supprimer les activités déjà enregistrées.
	* Le bouton "Importer les données" qui permet d'importer les information d'un fichier .json.
Tous ces boutons ne redirigent pas vers une autre vue (excepté le bouton "Déconnexion") mais permettent d'afficher
les différentes fonctionnalités sur cette même vue. Il n'y a donc aussi qu'un seul controlleur pour gérer cette
vue (ConnectedController.php).





