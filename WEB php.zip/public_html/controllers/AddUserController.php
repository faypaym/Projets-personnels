<?php
require('Controller.php');
require_once('model/UtilisateurDAO.php');
require_once('model/Utilisateur.php');
$mail = '';
$nomUt = '';
$prenomUt = '';
$sexe = '';
$dateNais = '';
$mdp = '';
$poids = '';

class AddUserController implements Controller {

   public function handle($request){
		global $mail;
		global $nomUt;
		global $prenomUt;
		global $sexe;
		global $dateNais;
		global $mdp;
		global $poids;
		
		global $erreurInscr;
		global $inscrReussie;
		
		$uad = UtilisateurDAO::getInstance();
	   
		if(isset($_POST['btn-reg'])) {
			$mail = $_POST['mail'];
			$nomUt = $_POST['nom'];
			$prenomUt = $_POST['prenom'];
			$sexe = $_POST['sexe'];
			$dateNais = $_POST['naissance'];
			$mdp = $_POST['mdp'];
			$poids = $_POST['poids'];
			
			if(!$uad->exists($mail)) {
				$ut = new Utilisateur();
				$ut -> init($mail,$nomUt,$prenomUt,$sexe,$dateNais,$mdp,$poids);
				$PTN = UtilisateurDAO::getInstance();
				$PTN -> insert($ut);
				$inscrReussie = true;
			}else{
				$erreurInscr = true;
			}
		}
    }
}

?>
