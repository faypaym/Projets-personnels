<?php
session_start();
require_once('Controller.php');
require_once('model/UtilisateurDAO.php');
require_once('model/PointDAO.php');
require_once('model/ActiviteDAO.php');
require_once('model/Activite.php');
require_once('model/Point.php');
require_once('model/JSonObj.php');

class ConnectedController implements Controller {
	
	public function handle($request){
		global $modify;
		global $accueil;
		global $activite;
		global $import;
		global $importErrForm;
		global $importEchec;
		global $importSuccess;
		global $idAct;
			
		if(isset($_POST['btn-dec'])) {
			unset($_SESSION['idCon']);
			session_destroy();
			header('Location:'."http://m3104.iut-info-vannes.net/m3104_17/index.php?page=user_connect");
			exit();
		}
		
		if(isset($_POST['btn-mod'])) {
			$modify = true;
			$import = false;
			$activite = false;
		}
		
		if(isset($_POST['btn-imp'])) {
			$modify = false;
			$import = true;
			$activite = false;
		}
		
		if(isset($_POST['btn-supAct'])) {
			$_SESSION['idAct'] = -1;
			ActiviteDAO::getInstance()->deleteAll();
			unset($_SESSION['idAct']);
		}
		
		if(isset($_POST['btn-act'])) {
			$modify = false;
			$import = false;
			$activite = true;
		}
		
		if(isset($_POST['btn-acc'])) {
			$modify = false;
			$import = false;
			$activite = false;
		}
		
		if(isset($_POST['btn-envMod'])) {
			UtilisateurDAO::getInstance()->update($_SESSION['idCon'], $_POST['prenom'], $_POST['nom'], $_POST['naissance'], $_POST['sexe'], $_POST['poids'], $_POST['mdp']);
		}
		
		if(isset($_POST['btn-envFile'])) {
			if(isset($_FILES['fileName'])) {
				$dossier = 'jsonfile/';
				$extensions = array('.json', '.zzarzer');
				$extension = strrchr($_FILES['fileName']['name'], '.');
				$fichier = basename($_FILES['fileName']['name']);

				if(move_uploaded_file($_FILES['fileName']['tmp_name'], $dossier . $fichier)) { //Si la fonction renvoie TRUE, c'est que ça a fonctionné...
					if(!in_array($extension, $extensions)) {
						unlink( $dossier."/".$fichier);
						$importErrForm = true;
					}else{
						$importSuccess = true;
						$jsonData = file_get_contents($dossier.$fichier);
						
						$array = json_decode($jsonData,true);
						
						$jsonObj = new JSonObj();
						$jsonObj->init($array);
						
						$actDao =  ActiviteDAO::getInstance();
						
						$idAct = $actDao -> getNextId();
						$dateAct = $jsonObj -> getDateAct();
						$descAct = $jsonObj -> getDescAct();
                        $debAct = $jsonObj -> getDebAct();
                        $duree = $jsonObj -> getDuree();
						$distanceParcourue = $jsonObj -> getDistanceParcourue();
                        $freqMoy = $jsonObj -> getFreqMoy();
                        $freqMin = $jsonObj -> getFreqMin();
                        $freqMax = $jsonObj -> getFreqMax();
    
                        //On récupère le plus grand ID de la table Activite et on ajoute la prochaine ligne avec un ID incrémenté 
    
                        $act = new Activite();
                        $act->init($idAct, ' ', $dateAct, $descAct, $debAct, $duree, $distanceParcourue, $freqMin, $freqMoy, $freqMax, $_SESSION['idCon']);
                        
                        for($i=0; $i < sizeof($array['data']); $i++){
							$latitude = $array['data'][$i]['latitude'];
                            $longitude = $array['data'][$i]['longitude'];
                            $altitude = $array['data'][$i]['altitude'];
                            $temps = $array['data'][$i]['time'];
                            $cardio = $array['data'][$i]['cardio_frequency'];
                            
                            $pt = new Point();
                            $pt->init($i, $latitude, $longitude, $altitude, $temps, $cardio, $idAct);
							
                            PointDAO::getInstance() -> insert($pt);
                        }

                        $actDao -> insert($act);
						
						unlink( $dossier."/".$fichier);
						
					}
				}else{ //Sinon (la fonction renvoie FALSE).
					$importEchec = true;
				}
			}
		}
    }	
}
?>
