<?php
require('Controller.php');
require_once('model/UtilisateurDAO.php');
$email = '';
$mdp = '';
class ConnectionController implements Controller {
	
	public function handle($request){
		global $email;
		global $mdp;
		global $erreurConnex;
		
		$uad = UtilisateurDAO::getInstance();

		// $uad->deleteAll();
		
		if(isset($_POST['btn-con'])) {
			$email = $_POST['mail'];
			$mdp = $_POST['mdp'];
			if($uad->connect($email,$mdp)) {
				session_start();
				$_SESSION['idCon'] = $email;
				header('Location:'."http://m3104.iut-info-vannes.net/m3104_17/index.php?page=user_connected");
				exit();
			}else{
				$erreurConnex = true;
			}
		}
    }
}
?>

