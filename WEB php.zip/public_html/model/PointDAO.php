<?php
require_once('SqliteConnection.php');
class PointDAO {
	private static $dao;

    private function __construct() {}

    public final static function getInstance() {
		if(!isset(self::$dao)) {
           self::$dao= new PointDAO();
		}
		return self::$dao;
    }

    public final function findAll(){
		$dbc = SqliteConnection::getInstance()-> getConnection();
		$query = "SELECT * FROM Point";
		$stmt = $dbc->query($query);
		$results = $stmt->fetchALL(PDO::FETCH_CLASS, 'Point');
		return $results;
    }

	public final function insert($pt){
		if($pt instanceof ptivite){
			$dbc = SqliteConnection::getInstance()-> getConnection();
			// prepare the SQL statement
			$query = "INSERT INTO ptivite(idPt, latitude, longitude, altitude, temps, cardio, lactivite) VALUES (:idpt, :latitude, :longitude, :altitude, :temps, :cardio, :lactivite)";
			$stmt = $dbc->prepare($query);

			// bind the paramaters
			$stmt->bindValue(':idpt',$pt->getIdPt(),PDO::PARAM_STR);
			$stmt->bindValue(':latitude',$pt->getLatitude(),PDO::PARAM_STR);
			$stmt->bindValue(':longitude',$pt->getLongitude(),PDO::PARAM_STR);
			$stmt->bindValue(':altitude',$pt->getAltitude(),PDO::PARAM_STR);
			$stmt->bindValue(':temps',$pt->getTemps(),PDO::PARAM_STR);
			$stmt->bindValue(':cardio',$pt->getCardio(),PDO::PARAM_STR);
			$stmt->bindValue(':lactivite',$pt->getLActivite(),PDO::PARAM_STR);

			// execpte the prepared statement
			$stmt->execute();
		}
	}
	
	public final function deleteAll(){
		$dbc = SqliteConnection::getInstance()-> getConnection();
		$query = "DELETE FROM Point";
		$stmt = $dbc->query($query);
    }
}
?>

