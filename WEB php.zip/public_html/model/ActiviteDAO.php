<?php
require_once('SqliteConnection.php');
class ActiviteDAO {
	private static $dao;

    private function __construct() {}

    public final static function getInstance() {
		if(!isset(self::$dao)) {
           self::$dao= new ActiviteDAO();
		}
		return self::$dao;
    }

    public final function findAll(){
		$dbc = SqliteConnection::getInstance()-> getConnection();
		$query = "SELECT * FROM Activite";
		$stmt = $dbc->query($query);
		$results = $stmt->fetchALL(PDO::FETCH_CLASS, 'Activite');
		return $results;
    }

	public final function insert($act){
		if($act instanceof Activite){
			$dbc = SqliteConnection::getInstance()-> getConnection();
			// prepare the SQL statement
			$query = "INSERT INTO Activite(idAct, nomAct, dateAct, descriptionAct, debut, duree, distanceParcourue, freqCardMin, freqCardMoy, freqCardMax, lutilisateur) VALUES (:idAct, :nomAct, :dateAct, :descriptionAct, :debut, :duree, :distanceParcourue, :freqCardMin, :freqCardMoy, :freqCardMax, :lutilisateur)";
			$stmt = $dbc->prepare($query);

			// bind the paramaters
			$stmt->bindValue(':idAct',$act->getIdAct(),PDO::PARAM_STR);
			$stmt->bindValue(':nomAct',$act->getNomAct(),PDO::PARAM_STR);
			$stmt->bindValue(':dateAct',$act->getDateAct(),PDO::PARAM_STR);
			$stmt->bindValue(':descriptionAct',$act->getDescriptionAct(),PDO::PARAM_STR);
			$stmt->bindValue(':debut',$act->getdebut(),PDO::PARAM_STR);
			$stmt->bindValue(':duree',$act->getDuree(),PDO::PARAM_STR);
			$stmt->bindValue(':distanceParcourue',$act->getDistanceParcourue(),PDO::PARAM_STR);
			$stmt->bindValue(':freqCardMin',$act->getFreqCardMin(),PDO::PARAM_STR);
			$stmt->bindValue(':freqCardMoy',$act->getFreqCardMoy(),PDO::PARAM_STR);
			$stmt->bindValue(':freqCardMax',$act->getFreqCardMax(),PDO::PARAM_STR);
			$stmt->bindValue(':lutilisateur',$act->getlutilisateur(),PDO::PARAM_STR);

			// execacte the prepared statement
			$stmt->execute();
		}
	}
	
	public final function getNextId(){
		$dbc = SqliteConnection::getInstance()->getConnection();
		$querry = "SELECT MAX(idAct) AS id FROM Activite";
		$stmt = $dbc->query($querry);
		$result = $stmt->fetch();
		$idAct = intval($result['id'])+1;
		return $idAct;
    }
	
	public final function getData($mail){
		$dbc = SqliteConnection::getInstance()->getConnection();
		$querry = "SELECT * FROM Activite WHERE lUtilisateur = '".$mail."'";
		$stmt = $dbc->query($querry);
		$result = $stmt->fetchAll();
		return $result;
    }
	
	public final function delete($idAct){
		$dbc = SqliteConnection::getInstance()->getConnection();
		$querry = "SELECT FROM Activite WHERE idAct = '".$idAct."'";
		$stmt = $dbc->query($querry);
    }
	
	public final function getNumberAct($mail) {
		$dbc = SqliteConnection::getInstance()->getConnection();
		$querry = "SELECT COUNT(*) FROM Activite WHERE lUtilisateur = '".$mail."'";
		$stmt = $dbc->query($querry);
		$result = $stmt->fetch();
		return $result;
	}
	
	public final function deleteAll(){
		$dbc = SqliteConnection::getInstance()-> getConnection();
		$query = "DELETE FROM Activite";
		$stmt = $dbc->query($query);
    }
	
	public final function secToTime($sec){
		$hours = floor($sec / 3600);
		$minute = floor($sec / 60) - ($hours*3600);
		$second = $sec - ($minute * 60) - ($hours*3600);
		return $hours."H ".$minute."min ".$second."sec";		
    }
}
?>

