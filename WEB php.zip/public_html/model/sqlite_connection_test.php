<?php



  ini_set('display_errors', 'On');
  error_reporting(E_ALL);
  require_once("SqliteConnection.php");
  require_once("Utilisateur.php");
  require_once("UtilisateurDAO.php");
//benoit
  require_once("ActivityEntryDAO.php");
  require_once("Point.php");
  require_once("Activite.php");
  require_once("ActiviteDAO.php");
 
 $connect = SqliteConnection::getInstance() -> getConnection();
  $ut1 = new Utilisateur;
  $ut1 -> init('test@free.fr','test','test','test','t','test','t');
  $UDAO = UtilisateurDAO::getInstance();
  //$UDAO -> delete('test@free.fr'); MARCHE PAS
  //$UDAO -> deleteALL();
  //$UDAO -> insert($ut1);


//benoit
  echo'POINT<br>';
  $point1 = new Point;
  $point1 -> init('1','2','3','4','5','6','7');
  $PTN = ActivityEntryDAO::getInstance();
  $PTN -> delete(1);//la methode pour supp une seule value  
  $PTN -> insert($point1);
  $sqlQuery= 'SELECT * FROM Point';
  $result = $connect->query($sqlQuery)->fetchAll();
  print_r($result);

  echo'<br><br>ACTIVITE<br>';
  $act1 = new Activite;
  $act1 -> init('1','run1','30','ctb1','22','6','70','80','90','1');
  $ACTEN = ActiviteDAO::getInstance();
  $ACTEN -> delete(1);  
  $ACTEN -> insert($act1);
  $sqlQuery= 'SELECT * FROM Activite';
  $result = $connect->query($sqlQuery)->fetchAll();
  print_r($result);
  echo'<br>';
//c pu benoit


  echo'<br>UTILISATEUR <br>';
  $sqlQuery= 'SELECT * FROM Utilisateur';
  $result = $connect->query($sqlQuery)->fetchAll();
  print_r($result);

 
?>