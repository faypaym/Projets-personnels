<?php
require_once('SqliteConnection.php');
require_once('model/Utilisateur.php');
class UtilisateurDAO {
    private static $dao;

    private function __construct() {}

	public final static function getInstance() {
       if(!isset(self::$dao)) {
           self::$dao= new UtilisateurDAO();
       }
       return self::$dao;
    }

    public final function findAll(){
		$dbc = SqliteConnection::getInstance()-> getConnection();
		$query = "SELECT * FROM Utilisateur";
		$stmt = $dbc->query($query);
		$results = $stmt->fetchALL(PDO::FETCH_CLASS, 'Utilisateur');
		return $results;
    }

	public final function insert($ut){
		if($ut instanceof Utilisateur){
			$dbc = SqliteConnection::getInstance()-> getConnection();
         
			// prepare the SQL statement
			$query = "INSERT INTO Utilisateur(mail, nomUt, prenomUt, sexe, dateNais, mdp ,poids) VALUES (:mail,:nomUt,:prenomUt,:sexe,:dateNais,:mdp,:poids)";
			$stmt = $dbc->prepare($query);

			// bind the paramaters
			$stmt->bindValue(':mail',$ut->getMail(),PDO::PARAM_STR);
			$stmt->bindValue(':nomUt',$ut->getNomUt(),PDO::PARAM_STR);
			$stmt->bindValue(':prenomUt',$ut->getPrenomUt(),PDO::PARAM_STR);
			$stmt->bindValue(':sexe',$ut->getSexe(),PDO::PARAM_STR);
			$stmt->bindValue(':dateNais',$ut->getDateNais(),PDO::PARAM_STR);
			$stmt->bindValue(':mdp',$ut->getMdp(),PDO::PARAM_STR);
			$stmt->bindValue(':poids',$ut->getPoids(),PDO::PARAM_STR);

			// execute the prepared statement
			$stmt->execute();
		}
	}
  
	public final function deleteAll(){
		$dbc = SqliteConnection::getInstance()-> getConnection();
		$query = "DELETE FROM Utilisateur";
		$stmt = $dbc->query($query);
    }
	
	public function exists($mail) {
		$ret = false;
		$dbc = SqliteConnection::getInstance()-> getConnection();
		$query = "SELECT * FROM Utilisateur WHERE mail = '".$mail."'";
		$stmt = $dbc->query($query);
		$results = $stmt->fetchALL(PDO::FETCH_CLASS, 'Utilisateur');
		if($results!=null) {
			$ret = true;
		}
		return $ret;
	}
	
	public function connect($login, $password) {
		$ret = false;
		$dbc = SqliteConnection::getInstance()-> getConnection();
		$query = "SELECT * FROM Utilisateur WHERE mail = '".$login."' AND mdp = '".$password."'";
		$stmt = $dbc->query($query);
		$results = $stmt->fetchALL(PDO::FETCH_CLASS, 'Utilisateur');
		if($results!=null) {
			$ret = true;
		}
		return $ret;
	}
	
	
	public function getPrenom($mail) {
		$dbc = SqliteConnection::getInstance()-> getConnection();
		$query = "SELECT prenomUt FROM Utilisateur WHERE mail ='".$mail."'";
		$st = $dbc->prepare($query);
		$st->execute();
		$results = $st->fetch();
		return $results[0];
	}
	
	public function getNom($mail) {
		$dbc = SqliteConnection::getInstance()-> getConnection();
		$query = "SELECT nomUt FROM Utilisateur WHERE mail ='".$mail."'";
		$st = $dbc->prepare($query);
		$st->execute();
		$results = $st->fetch();
		return $results[0];
	}
	
	public function getdateNais($mail) {
		$dbc = SqliteConnection::getInstance()-> getConnection();
		$query = "SELECT dateNais FROM Utilisateur WHERE mail ='".$mail."'";
		$st = $dbc->prepare($query);
		$st->execute();
		$results = $st->fetch();
		return $results[0];
	}
	
	public function getSexe($mail) {
		$dbc = SqliteConnection::getInstance()-> getConnection();
		$query = "SELECT sexe FROM Utilisateur WHERE mail ='".$mail."'";
		$st = $dbc->prepare($query);
		$st->execute();
		$results = $st->fetch();
		return $results[0];
	}
	
	public function getPoids($mail) {
		$dbc = SqliteConnection::getInstance()-> getConnection();
		$query = "SELECT poids FROM Utilisateur WHERE mail ='".$mail."'";
		$st = $dbc->prepare($query);
		$st->execute();
		$results = $st->fetch();
		return $results[0];
	}
	  
	public function update($mail, $prenom, $nom, $nais, $sexe, $poids, $mdp){
		$dbc = SqliteConnection::getInstance()-> getConnection();
		$query = "UPDATE Utilisateur SET prenomUt='".$prenom."', nomUt='".$nom."', dateNais='".$nais."', sexe='".$sexe."', poids='".$poids."', mdp='".$mdp."' WHERE mail = '".$mail."'";
		$stmt = $dbc->query($query);
	}
	
	/*
	public function delete($obj){
		$dbc = SqliteConnection::getInstance()-> getConnection();
		$query = "DELETE FROM Utilisateur WHERE mail = $obj";
		$stmt = $dbc->query($query); 
	}*/
	
}
?>

