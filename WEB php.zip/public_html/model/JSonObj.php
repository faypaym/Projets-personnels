<?php
require('model/CalculDistance.php');

class JSonObj{
    private $array;
    private $sizeArray;

    public function __construct(){}
    
    public function init(Array $array){
        $this->array = $array;
        $this->sizeArray = sizeof($array['data']);
    }

    public function getDateAct(){
        return $this->array['activity']['date'];
    }
	
	public function getDescAct(){
        return $this->array['activity']['description'];
    }
	
	public function getDebAct(){
        if($this->sizeArray > 0){
            $hDebut = $this->array['data'][0]['time'];
            $hFin = strtotime("00:00:00"); 
            $hDebut = strtotime($hDebut); 
            $hDebut = abs($hFin - $hDebut);
        }
        return $hDebut;
    }

    public function getDuree(){
        if($this->sizeArray > 0){
            $tempsDeb = strtotime($this->array['data'][0]['time']);
            $tempsFin = strtotime($this->array['data'][$this->sizeArray-1]['time']);
            $tempsTotal = abs($tempsDeb-$tempsFin);
        }else{
            $tempsTotal = 0;
        }
        return $tempsTotal;
    }
	
	public function getDistanceParcourue(){
		$distance = 0;
        $calculDist = new CalculDistance();
        $distance = $calculDist->calculDistanceTrajet($this->array);
        $distance = number_format($distance,3);
        return $distance;
    }
	
	public function getFreqMin(){
        if($this->sizeArray > 0){
            $freqMin = $this->array['data'][0]['cardio_frequency'];
            for($i = 1; $i < $this->sizeArray; $i++){
                if($this->array['data'][$i]['cardio_frequency'] < $this->array['data'][$i-1]['cardio_frequency']){
                    $freqMin = $this->array['data'][$i]['cardio_frequency'];
                }
            }
        }else{
            $freqMin = 0;
        }
        return $freqMin;
    }

    public function getFreqMoy(){
        $freqMoy = 0;
        for($i=0; $i < $this->sizeArray; $i++){
            $freqMoy += $this->array['data'][$i]['cardio_frequency'];
        }
        if($this->sizeArray != 0){
            $freqMoy = number_format($freqMoy/$this->sizeArray,1);
        }
        return $freqMoy;
    }
	
	public function getFreqMax(){
        if($this->sizeArray > 0){
            $freqMax = $this->array['data'][0]['cardio_frequency'];
            for($i = 1; $i < $this->sizeArray; $i++){
                if($this->array['data'][$i]['cardio_frequency'] > $this->array['data'][$i-1]['cardio_frequency']){
                    $freqMax = $this->array['data'][$i]['cardio_frequency'];
                }
            }
        }else{
            $freqMax = 0;
        }

        return $freqMax;
    }
}

?>