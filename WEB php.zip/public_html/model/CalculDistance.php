<?php
class CalculDistance {

	function __construct() {}
	
	public function calculDistance2PointGPS($lat1, $lat2, $long1, $long2) {
		$R = 6378.137;
		$lat1 = ($lat1 * pi()) / 180;
		$lat2 = ($lat2 * pi()) / 180;
		$long1 = ($long1 * pi()) / 180;
		$long2 = ($long2 * pi()) / 180;
		$ret = $R * acos(sin($lat2)*sin($lat1)+cos($lat2)*cos($lat1)*cos($long2-$long1));
		return $ret;
	}

	public function calculDistanceTrajet($array) {
		$ret = 0;
		$sizeArray = sizeof($array['data']);
		for($i=0; $i < $sizeArray-1; $i++) {
			$lat1 = $array['data'][$i]['latitude'];
			$lat2 = $array['data'][$i+1]['latitude'];
			$long1 = $array['data'][$i]['longitude'];
			$long2 = $array['data'][$i+1]['longitude'];
			$ret += $this -> calculDistance2PointGPS($lat1, $lat2, $long1, $long2);
		}
		return $ret;
	}
}
?>
