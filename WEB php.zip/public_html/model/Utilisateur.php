<?php
class Utilisateur{
	private $mail;
	private $nomUt;
	private $prenomUt;
	private $sexe;
	private $dateNais;
	private $mdp;
	private $poids;

	public function  __construct() { }
	public function init($mail, $nomUt, $prenomUt, $sexe, $dateNais, $mdp, $poids){
		$this->mail = $mail;
		$this->nomUt = $nomUt;
		$this->prenomUt = $prenomUt;
		$this->sexe = $sexe;
		$this->dateNais = $dateNais;
		$this->mdp = $mdp;
		$this->poids = $poids;
	}

	public function getMail(){ return $this->mail; }
	public function getNomUt(){ return $this->nomUt; }
	public function getPrenomUt(){ return $this->prenomUt; }
	public function getSexe(){ return $this->sexe; }
	public function getDateNais(){ return $this->dateNais; }
	public function getMdp(){ return $this->mdp; }
	public function getPoids(){ return $this->poids; }
	public function  __toString() { return $this->mail. " ". $this->nomUt." ". $this->prenomUt." ". $this->sexe." ". $this->dateNais." ". $this->mdp." ". $this->poids; }
}
?>

