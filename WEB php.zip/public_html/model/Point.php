<?php
class Point{
	private $idPT;
	private $latitude;
	private $longitude;
	private $altitude;
	private $temps;
	private $cardio;
	private $lActivite;

public function __construct() { }

public function init($idPt, $latitude,$longitude,$altitude,$temps,$cardio,$lActivite){
	$this->idPt = $idPt;
	$this->latitude = $latitude;
	$this->longitude = $longitude;
	$this->altitude = $altitude;
	$this->temps = $temps;
	$this->cardio = $cardio;
	$this->lActivite = $lActivite;
}

public function getIdPt(){ return $this->idPt; }
public function getLatitude(){ return $this->latitude; }
public function getLongitude(){ return $this->longitude; }
public function getAltitude(){ return $this->altitude; }
public function getTemps(){ return $this->temps; }
public function getCardio(){ return $this->cardio; }
public function getLActivite(){ return $this->lActivite; }
public function __toString() { return $this->idPt. " ". $this->latitude. " ". $this->longitude. " ". $this->altitude. " ". $this->temps. " ". $this->cardio. " ". $this->lActivite; }
}
?>
