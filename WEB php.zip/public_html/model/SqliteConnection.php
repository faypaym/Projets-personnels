<?php
ini_set('display_errors', 'On');
error_reporting(E_ALL);

class SqliteConnection {
	private static $instance;
        
	private function __construct(){}
	  
	public final static function getInstance() {
	    if(is_null(self::$instance)) {
	      self::$instance= new SqliteConnection(); 
	    }
	    return self::$instance;
	}
       
	  
	function getConnection() {
		try{
			$strConnection = new PDO('sqlite:DB/sport_track.db');
			$strConnection ->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	    }catch (PDOException $e) {
			print "Error!: " .$e->getMessage() . "<br>";
			die();
	    }
		return $strConnection;
	}
}
?>
