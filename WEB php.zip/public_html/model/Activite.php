<?php
class Activite{
	private $idAct;
	private $nomAct;
	private $dateAct;
	private $descriptionAct;
	private $debut;
	private $duree;
	private $distanceParcourue;
	private $freqCardMin;
	private $freqCardMoy;
	private $freqCardMax;
	private $lUtilisateur;

	public function  __construct() { }
	public function init($idAct, $nomAct, $dateAct, $descriptionAct, $debut, $duree, $distanceParcourue, $freqCardMin, $freqCardMoy, $freqCardMax, $lUtilisateur){
		$this->idAct = $idAct;
		$this->nomAct = $nomAct;
		$this->dateAct = $dateAct;
		$this->descriptionAct = $descriptionAct;
		$this->debut = $debut;
		$this->duree = $duree;
		$this->distanceParcourue = $distanceParcourue;
		$this->freqCardMin = $freqCardMin;
		$this->freqCardMoy = $freqCardMoy;
		$this->freqCardMax = $freqCardMax;
		$this->lUtilisateur = $lUtilisateur;
	}

	public function getIdAct(){ return $this->idAct; }
	public function getNomAct(){ return $this->nomAct; }
	public function getDateAct(){ return $this->dateAct; }
	public function getDescriptionAct(){ return $this->descriptionAct; }
	public function getDebut(){ return $this->debut; }
	public function getDuree(){ return $this->duree; }
	public function getDistanceParcourue(){ return $this->distanceParcourue; }
	public function getFreqCardMin(){ return $this->freqCardMin; }
	public function getFreqCardMoy(){ return $this->freqCardMoy; }
	public function getFreqCardMax(){ return $this->freqCardMax; }
	public function getlUtilisateur(){ return $this->lUtilisateur; }
	public function  __toString() { return $this->idAct. " ". $this->nomAct." ". $this->dateAct." ". $this->descriptionAct." ". $this->debut." ". $this->duree." ". $this->distanceParcourue." ". $this->freqCardMin." ". $this->freqCardMoy." ". $this->freqCardMax." ". $this->lUtilisateur; }
	}
?>


