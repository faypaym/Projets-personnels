<?php
require_once('controllers/AddUserController.php');
?>

<!DOCTYPE html>
<html>
	<link href="views/css.css" rel="stylesheet"> 
	<head>
		<meta charset="utf-8">
	</head>
	
	<body>
		<center class="encadrement">
			<h2>Inscription :</h2>
			<form method="POST" action="http://m3104.iut-info-vannes.net/m3104_17/index.php?page=user_add_form">
				<?php if(isset($erreurInscr)) { ?>
					<p id="erreurInscrForm"> <?php echo 'Email déjà utilisé'; ?></p>
				<?php } ?>
				
				<label for="prenom"> <span> Prénom : </span> </label>
				<input type="text" required id="prenom" name="prenom" size = "20"/>
				
				<br>
				<br>
				<label for="nom"> <span> Nom : </span> </label>
				<input type="text" required id="nom" name="nom" size = "20"/>
				
				<br>
				<br>
				<label for="naissance"> <span id="inscDateNais"> Naissance : </span> </label>
				<input type="date" id="naissance" name="naissance" size = "20"/>
				
				<br>
				<br>
				<label for="sexe"> <span> Sexe : </span> </label>
				<input type="text" required id="sexe" name="sexe" size = "20"/>
				
				<br>
				<br>
				<label for="poids"> <span> Poids : </span> </label>
				<input type="number" id="poids" name="poids" size = "20"/>
				
				<br>
				<br>
				<label for="mail"> <span> Email : </span> </label>
				<input type="email" required id="mail" name="mail" size = "20"/>
				
				<br>
				<br>
				<label for="mdp"> <span> Mot de passe : </span> </label>
				<input type="password" required id="mdp" name="mdp" size = "20"/>
				
				<?php if(isset($inscrReussie)) { ?>
				<p class="infoForm"> <?php echo 'Inscription réussie !'; ?></p>
				<?php } ?>
				
				<br>
				<br>
				<input id='inputBouton' type="submit" value="S'inscrire" name="btn-reg" /> 	
				<br>
				<p class="lienSousForm"> <a href="http://m3104.iut-info-vannes.net/m3104_17/index.php?page=user_connect"> Déjà inscrit ?</a></p>
			</form>	
		</center>
	</body>
</html>
