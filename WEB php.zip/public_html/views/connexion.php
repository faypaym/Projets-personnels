<?php
require_once('controllers/ConnectionController.php');
?>

<!DOCTYPE html>
<html>
	<link href="views/css.css" rel="stylesheet"> 
	<head>
		<meta charset="utf-8">
	</head>
	<body>
		<center class="encadrement">
			<h2>Connexion</h2>
			<form method="POST" action="http://m3104.iut-info-vannes.net/m3104_17/index.php?page=user_connect">
				<?php if(isset($erreurConnex)) { ?>
				<p class="erreurForm"> <?php echo 'Email ou mot de passe saisi est incorrect'; ?></p>
				<?php } ?>	
				<p>
				<label for="mail"> <span> Email : </span> </label>
				<input type="email" id="mail" name="mail" size = "20"/>
				<br>
				<br>
				
				<label for="mdp"> <span> Mot de passe :</span> </label>
				<input type="password" id="mdp" name="mdp" size = "20"/>
				<br>
				<br>
				</p>
				
				<input type="submit" value="Connexion" name="btn-con"  id="butCon"/> 	
				<br>
				<p class="lienSousForm"> <a href="http://m3104.iut-info-vannes.net/m3104_17/index.php?page=user_add_form"> Créer un compte ?</a></p>		
			</form>
		</center>
	</body>
</html>