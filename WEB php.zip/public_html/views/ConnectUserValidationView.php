<?php
require_once('controllers/ConnectedController.php');
require_once('model/UtilisateurDAO.php');
?>

<!doctype html>
<html lang="fr">
    <head>
    <link href="views/css.css" rel="stylesheet"> 
    </head>
    <body>	
		<div id='bandeau'></div>
		<p id='msgAccueil'> Bienvenue <?php print (UtilisateurDAO::getInstance()->getPrenom($_SESSION['idCon'])); ?> </p>
		<form method="POST" action="http://m3104.iut-info-vannes.net/m3104_17/index.php?page=user_connected">
			<input type="submit" value="Accueil" name="btn-acc" id="boutonAccueil" class="connectedBouton"/> 
			<input type="submit" value="Modifier le profil" name="btn-mod" id="boutonModif" class="connectedBouton"/> 
			<input type="submit" value="Liste d'activités" name="btn-act" id="boutonAct" class="connectedBouton"/> 
			<input type="submit" value="Importer des données" name="btn-imp" id="boutonImp" class="connectedBouton"/>
			<input type="submit" value="Déconnexion" name="btn-dec" id="boutonDec" class="connectedBouton"/>
		</form>
		
		<?php if($modify === true) { ?>
			<div class="encadrement">
				<center>
					<h2>Modifier le profil</h2>
					<form method="POST" action="http://m3104.iut-info-vannes.net/m3104_17/index.php?page=user_connected">
						<label for="prenom"> <span> Prénom : </span> </label>
						<input type="text" required id="prenom" name="prenom" value="<?php print (UtilisateurDAO::getInstance()->getPrenom($_SESSION['idCon'])); ?>" size = "20"/>
						
						<br>
						<br>
						<label for="nom"> <span> Nom : </span> </label>
						<input type="text" required id="nom" name="nom" value="<?php print (UtilisateurDAO::getInstance()->getNom($_SESSION['idCon'])); ?>" size = "20"/>
						
						<br>
						<br>
						<label for="naissance" id="inscDateNais"> <span> Naissance : </span> </label>
						<input type="date" id="naissance" name="naissance" value="<?php print (UtilisateurDAO::getInstance()->getDateNais($_SESSION['idCon'])); ?>" size = "20"/>
						
						<br>
						<br>
						<label for="sexe"> <span> Sexe : </span> </label>
						<input type="text" required id="sexe" name="sexe" value="<?php print (UtilisateurDAO::getInstance()->getSexe($_SESSION['idCon'])); ?>" size = "20"/>
						
						<br>
						<br>
						<label for="poids"> <span> Poids : </span> </label>
						<input type="number" id="poids" name="poids" value="<?php print (UtilisateurDAO::getInstance()->getPoids($_SESSION['idCon'])); ?>" size = "20"/>
						
						<br>
						<br>
						<label for="mail"> <span> Email : </span> </label>
						<input type="email" disabled required id="mail" name="mail" value="<?php print ($_SESSION['idCon']); ?>" size = "20"/>
						
						<br>
						<br>
						<label for="mdp"> <span> Mot de passe : </span> </label>
						<input type="password" required id="mdp" name="mdp" size = "20"/>
						
						<br>
						<br>
						<input type="submit" value="Envoyer" name="btn-envMod" class="boutonArrondi"/> 	
					</form>
				</center>
			</div>
		<?php } ?>
		
		<?php if($import === true) { ?>
			<div class="encadrement">
				<center>
				<h1>Upload</h1>
					<form method="POST" action="http://m3104.iut-info-vannes.net/m3104_17/index.php?page=user_connected" enctype="multipart/form-data">
						Fichier : 
						<input type="file" name="fileName">
						<input type="submit" name="btn-envFile" value="Envoyer le fichier" class="boutonArrondi" id="envoyerUpload">
					</form>
				</center>
			</div>
		<?php } ?>
		
		<?php if($importEchec === true) { ?>
			<div class="encadrement">
				<p class='msgErreurImport'> Échec de l'upload </p>
			</div>
		<?php } ?>
		
		<?php if($importErrForm === true) { ?>
			<div class="encadrement">
				<p class='msgErreurImport'> Fichier au mauvais format, veuillez rentrer un fichier en .json </p>
			</div>
		<?php } ?>
		
		<?php if($importSuccess === true) { ?>
			<div class="encadrement">
				<p class='msgErreurImport'> Upload effectué avec succès </p>
			</div>
		<?php } ?>
		
		
		<?php if($activite === true) { ?>
			<?php foreach(ActiviteDAO::getInstance() -> getData($_SESSION['idCon']) as $lineAct){?>
				<center>
					<table class="tableau">
						<tr>
							<th>Date</th>
							<th>Description</th>
							<th>Debut</th>
							<th>Duree</th>
							<th>Distance parcourue</th>
							<th>Fréquence minimale</th>
							<th>Fréquence moyenne</th>
							<th>Fréquence maximale</th>
						</tr>
						<tr>
							<td><?php print ($lineAct['dateAct']); ?></td>
							<td><?php print ($lineAct['descriptionAct']); ?></td>
							<td><?php print date("H:i:s", mktime(0,0,($lineAct['debut']))); ?></td>
							<td><?php print ActiviteDAO::getInstance() -> secToTime(($lineAct['duree'])); ?></td>
							<td><?php print (($lineAct['distanceParcourue'])." km"); ?></td>
							<td><?php print ($lineAct['freqCardMin']." bpm"); ?></td>
							<td><?php print ($lineAct['freqCardMoy']." bpm"); ?></td>
							<td><?php print ($lineAct['freqCardMax']." bpm"); ?></td>
							<br>
						</tr>
					</table>
				</center>
			<?php } ?>
			<center>
				<form method="POST" action="http://m3104.iut-info-vannes.net/m3104_17/index.php?page=user_connected">
					<input type="submit" name="btn-supAct" value="Supprimer Activités" class="boutonArrondi" id="boutonSuppAct">
				</form>
			</center>
		<?php } ?>
	</body>
</html>